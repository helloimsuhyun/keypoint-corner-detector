"""Centralized visualization controller for detector and validator views."""

from __future__ import annotations

import numpy as np
from .view3d import (
    open_cornervins_plane_views,
    open_plane_edge_graph_view,
    open_plane_edge_refiner_view,
    show_dense_score_heatmaps,
    show_detector_validator_results as render_detector_validator_results,
)


_VIEW_KEYS = (
    "pending_query",
    "plane_cluster_analysis",
    "plane_edge_graph_result",
    "plane_edge_debug_clustering",
    "plane_edge_debug_config",
)


def prepare_plane_edge_graph_view(frozen, result, *, show_3d=True):
    """Install and visualize new opt-in plane/edge graph analysis."""
    frozen['plane_edge_graph_result'] = result
    if show_3d:
        frozen['plane_edge_graph_view'] = open_plane_edge_graph_view(
            frozen['points_voxel_mm'], result,
            frozen.get('plane_edge_graph_view'),
        )
        frozen['plane_edge_refiner_view'] = open_plane_edge_refiner_view(
            frozen['points_voxel_mm'], result,
            frozen.get('plane_edge_refiner_view'),
        )


def show_plane_edge_graph_view(frozen, *, show_3d=True):
    """Open stored stage-4 output after the stage-3 2-D GUI is ready."""
    result = frozen.get("plane_edge_graph_result")
    if not show_3d or result is None:
        return
    frozen["plane_edge_graph_view"] = open_plane_edge_graph_view(
        frozen["points_voxel_mm"], result,
        frozen.get("plane_edge_graph_view"),
    )
    frozen["plane_edge_refiner_view"] = open_plane_edge_refiner_view(
        frozen["points_voxel_mm"], result,
        frozen.get("plane_edge_refiner_view"),
    )


def prepare_cornervins_plane_views(
    frozen,
    analysis,
    *,
    cfg,
    show_3d=True,
):
    """Show coarse/refined AHC, RANSAC planes, and final convex hulls."""
    frozen["plane_cluster_analysis"] = analysis
    if not show_3d:
        return
    context = frozen.get("organized_plane_context")
    if context is None:
        raise ValueError("CornerVINS visualization requires organized_plane_context")
    frozen["cornervins_plane_views"] = open_cornervins_plane_views(
        frozen["points_voxel_mm"],
        context["organized_points_mm"],
        analysis,
        frozen.get("cornervins_plane_views", ()),
        show_ahc=bool(getattr(cfg, "cornervins_show_ahc_regions", True)),
        show_patches=bool(getattr(cfg, "cornervins_show_plane_patches", True)),
        show_hulls=bool(getattr(cfg, "cornervins_show_convex_hulls", True)),
    )


def poll_view_events(frozen):
    """Service non-blocking Open3D windows."""
    for key in (
        "plane_edge_graph_view", "plane_edge_refiner_view",
    ):
        view = frozen.get(key)
        if view is None:
            continue
        if view.poll_events():
            view.update_renderer()
        else:
            view.destroy_window()
            frozen[key] = None
    corner_views = list(frozen.get("cornervins_plane_views", ()))
    if corner_views:
        for index, view in enumerate(corner_views):
            if view is None:
                continue
            if view.poll_events():
                view.update_renderer()
            else:
                view.destroy_window()
                corner_views[index] = None
        frozen["cornervins_plane_views"] = tuple(corner_views)


def close_query_views(frozen):
    for key in (
        "plane_edge_graph_view", "plane_edge_refiner_view",
    ):
        view = frozen.pop(key, None)
        if view is not None:
            view.destroy_window()
    for view in frozen.pop("cornervins_plane_views", ()):
        if view is not None:
            view.destroy_window()
    for key in _VIEW_KEYS:
        frozen.pop(key, None)


def show_dense_heatmaps(
    points_mm,
    score_result,
    cfg,
    *,
    rgb_points_mm=None,
    rgb_colors_rgb=None,
):
    """Display score fields and an optional registered-RGB candidate view."""
    if not cfg.show_3d:
        return
    show_dense_score_heatmaps(
        np.asarray(points_mm, dtype=np.float64),
        score_result,
        marker_radius_mm=max(0.8, 0.65 * cfg.voxel_3d_mm),
        rgb_points_mm=rgb_points_mm,
        rgb_colors_rgb=rgb_colors_rgb,
    )


def show_detector_validator_results(points_mm, validation, cfg):
    """Open the detector's final-only edge/corner result window."""
    render_detector_validator_results(
        np.asarray(points_mm, dtype=np.float64), validation,
        voxel_3d_mm=cfg.voxel_3d_mm,
    )


__all__ = [
    "close_query_views",
    "poll_view_events",
    "prepare_cornervins_plane_views",
    "prepare_plane_edge_graph_view",
    "show_dense_heatmaps",
    "show_detector_validator_results",
]
