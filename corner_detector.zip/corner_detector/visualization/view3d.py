"""Open3D views for active detector and plane/edge diagnostics."""

from __future__ import annotations

import matplotlib
import numpy as np

matplotlib.use("Agg", force=True)

from pointcloud_inputs.visualization import require_open3d
from ..plane_projection import normalize


_PLANE_COLORS = np.asarray([
    [0.20, 0.65, 0.95],
    [1.00, 0.55, 0.10],
    [0.35, 0.85, 0.35],
], dtype=np.float64)

_REFINER_EDGE_COLORS = {
    1: np.asarray([1.00, 0.62, 0.08], dtype=np.float64),
    2: np.asarray([0.05, 0.92, 1.00], dtype=np.float64),
    3: np.asarray([0.86, 0.22, 1.00], dtype=np.float64),
}

class _LazyOpen3D:
    def __getattr__(self, name):
        return getattr(require_open3d(), name)


o3d = _LazyOpen3D()


def centroid_saliency_colors(scores):
    """Map dimensionless CED scores to a fixed 0..1 turbo heatmap."""
    values = np.asarray(scores, dtype=float).reshape(-1)
    if not np.isfinite(values).all():
        raise ValueError("CED scores must be finite")
    return matplotlib.colormaps["turbo"](np.clip(values, 0.0, 1.0))[:, :3]


def dense_heatmap_colors(scores, valid_mask, *, vmax=1.0):
    """Map ``0..vmax`` to Turbo and reserve gray for invalid voxel points."""
    values = np.asarray(scores, dtype=np.float64).reshape(-1)
    valid = np.asarray(valid_mask, dtype=bool).reshape(-1)
    upper = float(vmax)
    if len(values) != len(valid):
        raise ValueError("scores and valid_mask must have the same length")
    if not np.isfinite(values).all():
        raise ValueError("Dense heatmap scores must be finite")
    if not np.isfinite(upper) or upper < 0.0:
        raise ValueError("vmax must be finite and non-negative")
    normalized = (
        np.zeros_like(values)
        if upper == 0.0
        else np.clip(values / upper, 0.0, 1.0)
    )
    colors = centroid_saliency_colors(normalized)
    colors[~valid] = [0.28, 0.28, 0.30]
    return colors


def pca_ratio_heatmap_colors(score_result, *, vmax=1.0):
    """Color the PCA ratio actually consumed by fusion.

    ``pca_ratio_saturated`` is identical to the raw ratio when tau is None,
    and contains the tanh-transformed ratio when saturation is configured.
    """
    ratio = np.asarray(
        score_result["pca_ratio_saturated"], dtype=np.float64,
    ).reshape(-1)
    valid = np.asarray(score_result["pca_valid_mask"], dtype=bool).reshape(-1)
    queried = np.asarray(score_result["pca_query_mask"], dtype=bool).reshape(-1)
    invalid = np.asarray(
        score_result["invalid_support_mask"], dtype=bool,
    ).reshape(-1)
    for name, mask in (
        ("pca_valid_mask", valid),
        ("pca_query_mask", queried),
        ("invalid_support_mask", invalid),
    ):
        if len(mask) != len(ratio):
            raise ValueError(f"{name} must align with pca_ratio_saturated")
    colors = dense_heatmap_colors(ratio, valid, vmax=vmax)
    colors[~queried] = [0.16, 0.16, 0.18]
    colors[invalid] = [0.58, 0.58, 0.62]
    return colors


def dense_heatmap_vmax(score_result, quantile=0.99):
    """Return Q-based display maxima without modifying numerical scores.

    Original CED defines the shared range for point-wise and Bilateral CED. The
    dimensionless PCA ratio and Fusion score each receive their own range.
    Invalid samples are excluded from quantiles.
    """
    q = float(quantile)
    if not np.isfinite(q) or not 0.0 <= q <= 1.0:
        raise ValueError("quantile must be finite and in [0, 1]")

    def valid_quantile(value_key, mask_key):
        values = np.asarray(score_result[value_key], dtype=np.float64).reshape(-1)
        valid = np.asarray(score_result[mask_key], dtype=bool).reshape(-1)
        if len(values) != len(valid):
            raise ValueError(f"{value_key} and {mask_key} must have the same length")
        if not np.isfinite(values).all():
            raise ValueError(f"{value_key} must be finite")
        selected = values[valid]
        return 0.0 if len(selected) == 0 else float(np.quantile(selected, q))

    ced_shared = valid_quantile("ced_score", "ced_valid_mask")
    pca = valid_quantile("pca_ratio_saturated", "pca_valid_mask")
    fusion = valid_quantile("fusion_score", "fusion_valid_mask")
    return {
        "ced_score": ced_shared,
        "bilateral_ced_score": ced_shared,
        "pca_ratio_saturated": pca,
        "fusion_score": fusion,
    }


def corner_candidate_primitives(points_mm, score_result):
    """Return immutable marker/debug values for extracted 3-D candidates."""
    points = np.asarray(points_mm, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 3 or not np.isfinite(points).all():
        raise ValueError("points_mm must be finite with shape (N, 3)")
    extraction = score_result.get("candidate_extraction")
    if extraction is None:
        return {
            "indices": np.empty(0, dtype=np.int64),
            "positions_mm": np.empty((0, 3), dtype=np.float64),
            "ced_score": np.empty(0, dtype=np.float64),
            "bilateral_ced_score": np.empty(0, dtype=np.float64),
            "pca_ratio_raw": np.empty(0, dtype=np.float64),
            "pca_ratio_saturated": np.empty(0, dtype=np.float64),
            "pca_ratio_saturation_tau": score_result.get(
                "pca_ratio_saturation_tau"
            ),
            "fusion_score": np.empty(0, dtype=np.float64),
            "nms_radius_mm": 0.0,
            "candidate_count": 0,
        }
    indices = np.asarray(extraction["candidate_indices"], dtype=np.int64).reshape(-1)
    if np.any(indices < 0) or np.any(indices >= len(points)):
        raise IndexError("candidate_indices contains an out-of-range point index")
    ced = np.asarray(score_result["ced_score"], dtype=np.float64)
    bilateral = np.asarray(
        score_result.get("bilateral_ced_score", ced), dtype=np.float64,
    )
    pca_raw = np.asarray(score_result["pca_ratio_raw"], dtype=np.float64)
    pca_saturated = np.asarray(
        score_result["pca_ratio_saturated"], dtype=np.float64,
    )
    fusion_score = np.asarray(score_result["fusion_score"], dtype=np.float64)
    return {
        "indices": indices.copy(),
        "positions_mm": points[indices].copy(),
        "ced_score": ced[indices].copy(),
        "bilateral_ced_score": bilateral[indices].copy(),
        "pca_ratio_raw": pca_raw[indices].copy(),
        "pca_ratio_saturated": pca_saturated[indices].copy(),
        "pca_ratio_saturation_tau": score_result.get(
            "pca_ratio_saturation_tau"
        ),
        "fusion_score": fusion_score[indices].copy(),
        "nms_radius_mm": float(extraction["nms_radius_mm"]),
        "candidate_count": int(extraction["candidate_count"]),
    }


def _wire_sphere(center, radius, samples):
    center = np.asarray(center, dtype=np.float64).reshape(3)
    radius = float(radius)
    samples = int(samples)
    if not np.isfinite(center).all() or not np.isfinite(radius) or radius <= 0.0:
        raise ValueError("Wire-sphere center/radius must be finite and radius positive")
    if samples < 8:
        raise ValueError("Wire-sphere samples must be at least 8")
    angle = np.linspace(0.0, 2.0 * np.pi, samples, endpoint=False)
    cosine, sine = radius * np.cos(angle), radius * np.sin(angle)
    circles = (
        center + np.column_stack((cosine, sine, np.zeros(samples))),
        center + np.column_stack((cosine, np.zeros(samples), sine)),
        center + np.column_stack((np.zeros(samples), cosine, sine)),
    )
    sphere_points = np.vstack(circles)
    sphere_lines = []
    for circle_index in range(3):
        offset = circle_index * samples
        sphere_lines.extend(
            (offset + index, offset + (index + 1) % samples)
            for index in range(samples)
        )
    return sphere_points, np.asarray(sphere_lines, dtype=np.int32)


def cornervins_ahc_primitives(
    organized_points_mm,
    analysis,
    *,
    stage="coarse",
    circle_samples=96,
):
    """Build one organized AHC/RANSAC stage and the exact query ROI."""

    organized = np.asarray(organized_points_mm, dtype=np.float64)
    if organized.ndim != 3 or organized.shape[2] != 3:
        raise ValueError("organized_points_mm must have shape (H,W,3)")
    query = np.asarray(analysis["query_position_mm"], dtype=np.float64).reshape(3)
    radius = float(
        analysis.get(
            "organized_extraction_radius_mm",
            analysis["query_radius_mm"],
        )
    )
    if not np.isfinite(query).all() or not np.isfinite(radius) or radius <= 0.0:
        raise ValueError("CornerVINS query and radius must be finite and positive")

    valid = np.isfinite(organized).all(axis=2).reshape(-1)
    raw_pixels = np.flatnonzero(valid)
    raw = organized.reshape(-1, 3)[raw_pixels]
    lookup = np.full(valid.shape, -1, dtype=np.int64)
    lookup[raw_pixels] = np.arange(len(raw_pixels), dtype=np.int64)
    inside_roi = np.linalg.norm(raw - query, axis=1) <= radius + 1e-9
    colors = np.tile([0.14, 0.15, 0.17], (len(raw), 1))
    colors[inside_roi] = [0.42, 0.43, 0.46]
    palette = matplotlib.colormaps["tab20"]
    result = analysis["cornervins_result"]
    if stage == "coarse":
        groups = tuple(result.ahc_regions)
        patches = ()
    elif stage == "refined":
        membership = np.asarray(result.refined_membership_image, dtype=np.int32)
        if membership.shape != organized.shape[:2]:
            raise ValueError("refined AHC membership must match organized image")
        labels = np.unique(membership[membership >= 0])
        groups = tuple(
            np.flatnonzero(membership.reshape(-1) == label).astype(np.int64)
            for label in labels
        )
        patches = ()
    elif stage == "ransac":
        patches = tuple(getattr(result, "ransac_patches", ()))
        groups = tuple(patch.organized_inlier_indices for patch in patches)
    else:
        raise ValueError("stage must be coarse, refined, or ransac")

    for region_id, pixels in enumerate(groups):
        pixel_ids = np.asarray(pixels, dtype=np.int64).reshape(-1)
        if np.any(pixel_ids < 0) or np.any(pixel_ids >= valid.size):
            raise IndexError("organized stage contains an invalid pixel index")
        local = lookup[pixel_ids]
        local = local[local >= 0]
        colors[local] = palette((region_id % 20) / 19.0)[:3]
    sphere_points, sphere_lines = _wire_sphere(
        query, radius, int(circle_samples)
    )
    return {
        "points_mm": raw.copy(),
        "point_colors": colors,
        "inside_roi_mask": inside_roi,
        "query_position_mm": query.copy(),
        "query_radius_mm": radius,
        "sphere_points_mm": sphere_points,
        "sphere_lines": sphere_lines,
        "region_count": len(groups),
        "stage": stage,
        "plane_centers_mm": np.asarray(
            [patch.center for patch in patches], dtype=np.float64
        ).reshape(-1, 3),
        "plane_normals": np.asarray(
            [patch.normal for patch in patches], dtype=np.float64
        ).reshape(-1, 3),
    }


def cornervins_scene_roi_primitives(
    points_mm,
    analysis,
    *,
    circle_samples=96,
):
    """Build full-scene context colors and the exact CornerVINS query ROI."""

    points = np.asarray(points_mm, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 3 or not np.isfinite(points).all():
        raise ValueError("points_mm must be finite with shape (N,3)")
    roi_ids = np.asarray(analysis["roi_point_indices"], dtype=np.int64).reshape(-1)
    if np.any(roi_ids < 0) or np.any(roi_ids >= len(points)):
        raise IndexError("CornerVINS ROI contains an invalid scene index")
    query = np.asarray(analysis["query_position_mm"], dtype=np.float64).reshape(3)
    radius = float(analysis["query_radius_mm"])
    if not np.isfinite(query).all() or not np.isfinite(radius) or radius <= 0.0:
        raise ValueError("CornerVINS query and radius must be finite and positive")
    colors = np.tile([0.14, 0.15, 0.17], (len(points), 1))
    colors[roi_ids] = [0.42, 0.43, 0.46]
    sphere_points, sphere_lines = _wire_sphere(
        query, radius, int(circle_samples)
    )
    return {
        "points_mm": points.copy(),
        "point_colors": colors,
        "roi_point_indices": roi_ids.copy(),
        "query_position_mm": query.copy(),
        "query_radius_mm": radius,
        "sphere_points_mm": sphere_points,
        "sphere_lines": sphere_lines,
    }


def _camera_signature(parameters):
    """Return the numeric camera state used to detect the manipulated view."""
    intrinsic = np.asarray(
        parameters.intrinsic.intrinsic_matrix,
        dtype=np.float64,
    ).reshape(-1)
    extrinsic = np.asarray(parameters.extrinsic, dtype=np.float64).reshape(-1)
    return np.concatenate((intrinsic, extrinsic))


def synchronize_dense_camera_views(windows, active, previous_signatures):
    """Propagate the camera that changed since the previous render cycle.

    Returning ``master_index=None`` means no user-visible camera change was
    detected. This lets any dense-score or RGB window become the master,
    rather than continuously forcing the first window onto the others.
    """
    if len(windows) != len(active):
        raise ValueError("windows and active must have the same length")
    if previous_signatures is not None and len(previous_signatures) != len(windows):
        raise ValueError("previous_signatures must align with windows")

    parameters = [None] * len(windows)
    signatures = [None] * len(windows)
    for index, vis in enumerate(windows):
        if not active[index]:
            continue
        parameters[index] = (
            vis.get_view_control().convert_to_pinhole_camera_parameters()
        )
        signatures[index] = _camera_signature(parameters[index])

    if previous_signatures is None:
        return signatures, None
    changed = [
        index
        for index, signature in enumerate(signatures)
        if signature is not None
        and previous_signatures[index] is not None
        and not np.allclose(
            signature,
            previous_signatures[index],
            rtol=1e-8,
            atol=1e-10,
        )
    ]
    if not changed:
        return signatures, None

    # Normal interaction changes one window per event cycle. If multiple
    # windows changed, prefer the later panel deterministically.
    master_index = changed[-1]
    master_parameters = parameters[master_index]
    master_signature = signatures[master_index]
    for index, vis in enumerate(windows):
        if not active[index] or index == master_index:
            continue
        vis.get_view_control().convert_from_pinhole_camera_parameters(
            master_parameters,
            allow_arbitrary=True,
        )
        signatures[index] = master_signature.copy()
    return signatures, master_index


def dense_heatmap_panels():
    """Return the seven synchronized whole-cloud panel specifications."""
    return (
        ("Original Point Cloud", None, None, "geometry"),
        ("Point-wise CED", "ced_score", "ced_valid_mask", "CED range"),
        (
            "Bilateral CED",
            "bilateral_ced_score",
            "bilateral_valid_mask",
            "CED range",
        ),
        (
            "PCA Ratio Used for Fusion",
            "pca_ratio_saturated",
            "pca_valid_mask",
            "PCA range",
        ),
        (
            "Final Fusion Score",
            "fusion_score",
            "fusion_valid_mask",
            "Fusion Q99",
        ),
        (
            "NMS Corner Candidates",
            "fusion_score",
            "fusion_valid_mask",
            "Fusion Q99",
        ),
    )


def show_dense_score_heatmaps(
    points_mm,
    score_result,
    *,
    marker_radius_mm=1.0,
    rgb_points_mm=None,
    rgb_colors_rgb=None,
):
    """Show score fields and optional registered RGB in synchronized views."""
    points = np.asarray(points_mm, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 3 or not np.isfinite(points).all():
        raise ValueError("points_mm must be finite with shape (N, 3)")
    if (rgb_points_mm is None) != (rgb_colors_rgb is None):
        raise ValueError("rgb_points_mm and rgb_colors_rgb must be provided together")
    rgb_points = None
    rgb_colors = None
    if rgb_points_mm is not None:
        rgb_points = np.asarray(rgb_points_mm, dtype=np.float64)
        raw_rgb_colors = np.asarray(rgb_colors_rgb)
        if (
            rgb_points.ndim != 2
            or rgb_points.shape[1] != 3
            or not np.isfinite(rgb_points).all()
        ):
            raise ValueError("rgb_points_mm must be finite with shape (N, 3)")
        if raw_rgb_colors.shape != (len(rgb_points), 3):
            raise ValueError("rgb_colors_rgb must align with rgb_points_mm")
        integer_rgb = np.issubdtype(raw_rgb_colors.dtype, np.integer)
        rgb_colors = np.asarray(raw_rgb_colors, dtype=np.float64)
        if not np.isfinite(rgb_colors).all():
            raise ValueError("rgb_colors_rgb must be finite")
        if integer_rgb or (rgb_colors.size and np.max(rgb_colors) > 1.0):
            rgb_colors = rgb_colors / 255.0
        if np.any(rgb_colors < 0.0) or np.any(rgb_colors > 1.0):
            raise ValueError("rgb_colors_rgb values must be in [0, 1] or [0, 255]")
    display_vmax = dense_heatmap_vmax(score_result, quantile=0.99)
    candidate_debug = corner_candidate_primitives(points, score_result)
    panels = dense_heatmap_panels()
    windows = []
    panel_count = len(panels) + int(rgb_points is not None)

    def window_layout(index):
        if panel_count == 4:
            return {
                "width": 820,
                "height": 470,
                "left": 15 + 840 * (index % 2),
                "top": 35 + 490 * (index // 2),
            }
        if 7 <= panel_count <= 8:
            return {
                "width": 460,
                "height": 450,
                "left": 15 + 475 * (index % 4),
                "top": 35 + 470 * (index // 4),
            }
        if 5 <= panel_count <= 6:
            return {
                "width": 600,
                "height": 450,
                "left": 15 + 620 * (index % 3),
                "top": 35 + 470 * (index // 3),
            }
        return {
            "width": 600,
            "height": 760,
            "left": 15 + 620 * index,
            "top": 45,
        }

    def build_candidate_markers():
        if not len(candidate_debug["indices"]):
            return None
        markers = o3d.geometry.TriangleMesh()
        for position in candidate_debug["positions_mm"]:
            marker = o3d.geometry.TriangleMesh.create_sphere(
                radius=max(0.4, float(marker_radius_mm)),
                resolution=6,
            )
            marker.translate(position)
            marker.paint_uniform_color([1.0, 0.05, 0.03])
            markers += marker
        markers.compute_vertex_normals()
        return markers

    for panel_index, (label, key, valid_key, range_label) in enumerate(panels):
        values = (
            np.zeros(len(points), dtype=np.float64)
            if key is None
            else np.asarray(score_result[key], dtype=np.float64).reshape(-1)
        )
        if len(values) != len(points):
            raise ValueError(f"{key} must align with points_mm")
        valid = (
            np.ones(len(points), dtype=bool)
            if valid_key is None
            else np.asarray(score_result[valid_key], dtype=bool).reshape(-1)
        )
        if len(valid) != len(points):
            raise ValueError(f"{valid_key} must align with points_mm")
        selected = values[valid]
        data_range = (
            "none"
            if len(selected) == 0
            else f"{np.min(selected):.3f}..{np.max(selected):.3f}"
        )
        scale_text = (
            f"Q99={display_vmax[key]:.4g}" if key is not None else None
        )
        title = (
            f"{panel_index + 1} {label} | "
            + ("neutral geometry | " if key is None else
               f"Turbo 0..{scale_text} ({range_label}) | ")
            + f"valid={np.count_nonzero(valid)}/{len(points)} | data={data_range}"
        )
        if panel_index == 3:
            tau = score_result["pca_ratio_saturation_tau"]
            ratio_mode = "raw identity" if tau is None else f"saturated tau={tau}"
            title += (
                f" | queried={np.count_nonzero(score_result['pca_query_mask'])} "
                f"invalid={np.count_nonzero(score_result['invalid_support_mask'])} "
                f"mode={ratio_mode} "
            )
        if panel_index == 5:
            extraction = score_result["candidate_extraction"]
            title += (
                f" | {extraction.get('fusion_threshold_mode', 'fixed')}:"
                f"score>{extraction['fusion_score_threshold']:.4g} "
                f"| NMS={candidate_debug['candidate_count']} | M: markers ON/OFF"
            )
        vis = (
            o3d.visualization.VisualizerWithKeyCallback()
            if panel_index == 5
            else o3d.visualization.Visualizer()
        )
        layout = window_layout(panel_index)
        if not vis.create_window(
            window_name=title,
            **layout,
        ):
            for existing in windows:
                existing.destroy_window()
            raise RuntimeError("Failed to create dense heatmap windows")
        cloud = o3d.geometry.PointCloud()
        cloud.points = o3d.utility.Vector3dVector(points)
        ratio_colors = None
        if key is None:
            cloud.colors = o3d.utility.Vector3dVector(
                np.full((len(points), 3), 0.72, dtype=np.float64)
            )
        elif panel_index == 3:
            ratio_colors = pca_ratio_heatmap_colors(
                score_result,
                vmax=display_vmax[key],
            )
            cloud.colors = o3d.utility.Vector3dVector(ratio_colors)
        else:
            panel_colors = dense_heatmap_colors(
                values, valid, vmax=display_vmax[key],
            )
            cloud.colors = o3d.utility.Vector3dVector(
                panel_colors
            )
        vis.add_geometry(cloud)
        if panel_index == 5:
            markers = build_candidate_markers()
            if markers is not None:
                vis.add_geometry(markers)
                marker_state = {"visible": True}
                marker_label = "candidate"

                def toggle_markers(
                    callback_vis,
                    marker_geometry=markers,
                    state=marker_state,
                    label=marker_label,
                ):
                    if state["visible"]:
                        callback_vis.remove_geometry(
                            marker_geometry, reset_bounding_box=False,
                        )
                    else:
                        callback_vis.add_geometry(
                            marker_geometry, reset_bounding_box=False,
                        )
                    state["visible"] = not state["visible"]
                    print(
                        f"[HEATMAP] {label} markers "
                        + ("ON" if state["visible"] else "OFF"),
                        flush=True,
                    )
                    callback_vis.update_renderer()
                    return False

                vis.register_key_callback(ord("M"), toggle_markers)
        option = vis.get_render_option()
        if option is not None:
            option.background_color = np.array([0.025, 0.025, 0.025])
            option.point_size = 4.0
        windows.append(vis)

    if rgb_points is not None:
        rgb_panel_index = len(panels)
        title = (
            "RealSense RGB + corner candidates (auxiliary, not a heatmap) | "
            f"points={len(rgb_points)} | candidates={len(candidate_debug['indices'])}"
        )
        vis = o3d.visualization.Visualizer()
        if not vis.create_window(
            window_name=title,
            **window_layout(rgb_panel_index),
        ):
            for existing in windows:
                existing.destroy_window()
            raise RuntimeError("Failed to create RealSense RGB candidate window")
        cloud = o3d.geometry.PointCloud()
        cloud.points = o3d.utility.Vector3dVector(rgb_points)
        cloud.colors = o3d.utility.Vector3dVector(rgb_colors)
        vis.add_geometry(cloud)
        markers = build_candidate_markers()
        if markers is not None:
            vis.add_geometry(markers)
        option = vis.get_render_option()
        if option is not None:
            option.background_color = np.array([0.025, 0.025, 0.025])
            option.point_size = 3.0
        windows.append(vis)

    active = [True] * len(windows)
    camera_signatures, _master = synchronize_dense_camera_views(
        windows,
        active,
        None,
    )
    while any(active):
        for index, vis in enumerate(windows):
            if active[index]:
                active[index] = bool(vis.poll_events())
        if not any(active):
            break
        camera_signatures, _master = synchronize_dense_camera_views(
            windows,
            active,
            camera_signatures,
        )
        for index, vis in enumerate(windows):
            if active[index]:
                vis.update_renderer()
    for vis in windows:
        vis.destroy_window()


def open_cornervins_plane_views(
    points_mm,
    organized_points_mm,
    analysis,
    previous=(),
    *,
    show_ahc=True,
    show_patches=True,
    show_hulls=True,
):
    """Open coarse AHC, refined AHC, RANSAC, and final hull views."""

    for view in previous or ():
        if view is not None:
            view.destroy_window()
    points = np.asarray(points_mm, dtype=np.float64)
    organized = np.asarray(organized_points_mm, dtype=np.float64)
    result = analysis["cornervins_result"]
    query = np.asarray(analysis["query_position_mm"], dtype=np.float64)
    palette = matplotlib.colormaps["tab20"]
    views = []

    def finish(view, *, point_size=3.5):
        option = view.get_render_option()
        option.background_color = np.asarray([0.025, 0.028, 0.035])
        option.point_size = point_size
        option.line_width = 4.0
        control = view.get_view_control()
        control.set_lookat(query)
        control.set_front(normalize([0.75, 0.55, 0.65]))
        control.set_up(normalize([0.0, -1.0, 0.0]))
        control.set_zoom(0.72)
        return view

    def add_query_roi(view, primitive):
        roi = o3d.geometry.LineSet()
        roi.points = o3d.utility.Vector3dVector(primitive["sphere_points_mm"])
        roi.lines = o3d.utility.Vector2iVector(primitive["sphere_lines"])
        roi.colors = o3d.utility.Vector3dVector(
            np.tile([1.0, 0.82, 0.08], (len(primitive["sphere_lines"]), 1))
        )
        view.add_geometry(roi)

        query_marker = o3d.geometry.TriangleMesh.create_sphere(
            radius=max(1.0, 0.025 * primitive["query_radius_mm"]),
            resolution=8,
        )
        query_marker.translate(primitive["query_position_mm"])
        query_marker.paint_uniform_color([1.0, 0.08, 0.05])
        query_marker.compute_vertex_normals()
        view.add_geometry(query_marker)

    def open_organized_stage(*, stage, title, left, show_normals=False):
        primitive = cornervins_ahc_primitives(organized, analysis, stage=stage)
        view = o3d.visualization.Visualizer()
        if view.create_window(window_name=title, width=500, height=720, left=left, top=45):
            cloud = o3d.geometry.PointCloud()
            cloud.points = o3d.utility.Vector3dVector(primitive["points_mm"])
            cloud.colors = o3d.utility.Vector3dVector(primitive["point_colors"])
            view.add_geometry(cloud)
            if show_normals:
                for plane_id, (center, normal) in enumerate(
                    zip(primitive["plane_centers_mm"], primitive["plane_normals"])
                ):
                    color = np.asarray(palette((plane_id % 20) / 19.0)[:3])
                    normal_line = o3d.geometry.LineSet()
                    normal_line.points = o3d.utility.Vector3dVector(
                        np.vstack(
                            (
                                center,
                                center
                                + 0.18
                                * analysis["query_radius_mm"]
                                * normalize(normal),
                            )
                        )
                    )
                    normal_line.lines = o3d.utility.Vector2iVector([[0, 1]])
                    normal_line.colors = o3d.utility.Vector3dVector([color])
                    view.add_geometry(normal_line)
            add_query_roi(view, primitive)
            return finish(view, point_size=2.5)
        return None

    if show_ahc:
        for stage, title, left in (
            (
                "coarse",
                "CornerVINS 1/4 | coarse AHC (Feng Algorithm 3) | "
                f"R={analysis['query_radius_mm']:.1f}mm",
                10,
            ),
            (
                "refined",
                "CornerVINS 2/4 | refined AHC (Feng Algorithm 4)",
                490,
            ),
        ):
            view = open_organized_stage(
                stage=stage, title=title, left=left, show_normals=False
            )
            if view is not None:
                views.append(view)

    def open_patch_view(*, title, left, include_hulls):
        primitive = cornervins_scene_roi_primitives(points, analysis)
        colors = primitive["point_colors"].copy()
        view = o3d.visualization.Visualizer()
        if view.create_window(
            window_name=title, width=500, height=720, left=left, top=45,
        ):
            for plane in analysis["global_planes"]:
                plane_id = int(plane["plane_id"])
                color = np.asarray(palette((plane_id % 20) / 19.0)[:3])
                support = np.asarray(plane["support_indices"], dtype=np.int64)
                if np.any(support < 0) or np.any(support >= len(points)):
                    raise IndexError("CornerVINS plane support contains an invalid scene index")
                colors[support] = color
                center = np.asarray(plane["representative_center"], dtype=np.float64)
                normal = normalize(plane["representative_normal"])
                normal_line = o3d.geometry.LineSet()
                normal_line.points = o3d.utility.Vector3dVector(
                    np.vstack((center, center + 0.18 * analysis["query_radius_mm"] * normal))
                )
                normal_line.lines = o3d.utility.Vector2iVector([[0, 1]])
                normal_line.colors = o3d.utility.Vector3dVector([color])
                view.add_geometry(normal_line)
                hull = np.asarray(plane.get("hull_vertices_3d", ()), dtype=np.float64)
                if include_hulls and len(hull) >= 2:
                    boundary = o3d.geometry.LineSet()
                    boundary.points = o3d.utility.Vector3dVector(hull)
                    boundary.lines = o3d.utility.Vector2iVector(
                        np.asarray(
                            [[index, (index + 1) % len(hull)] for index in range(len(hull))],
                            dtype=np.int32,
                        )
                    )
                    boundary.colors = o3d.utility.Vector3dVector(
                        np.tile(np.clip(0.65 * color + 0.35, 0.0, 1.0), (len(hull), 1))
                    )
                    view.add_geometry(boundary)
            cloud = o3d.geometry.PointCloud()
            cloud.points = o3d.utility.Vector3dVector(primitive["points_mm"])
            cloud.colors = o3d.utility.Vector3dVector(colors)
            view.add_geometry(cloud)
            add_query_roi(view, primitive)
            return finish(view)
        return None

    if show_patches:
        view = open_organized_stage(
            stage="ransac",
            title=(
                "CornerVINS 3/4 | RANSAC accepted + LS refit | "
                f"planes={len(result.ransac_patches)}"
            ),
            left=970,
            show_normals=True,
        )
        if view is not None:
            views.append(view)

    if show_hulls:
        view = open_patch_view(
            title=(
                "CornerVINS 4/4 | merged final planes + convex hulls | "
                f"planes={len(analysis['global_planes'])} yellow=ROI red=query"
            ),
            left=1450,
            include_hulls=True,
        )
        if view is not None:
            views.append(view)

    return tuple(views)


def plane_edge_refiner_primitives(analysis):
    """Prepare refined segments with a stable 1/2/3-plane color category.

    A three-plane detector edge is expanded into plane-pair edges by the
    refiner. The category therefore comes from the immutable source edge,
    rather than the pair stored on each refined edge.
    """
    refinement = analysis.get("refinement")
    if not refinement:
        return []
    source_by_id = {
        int(edge["edge_id"]): edge for edge in analysis.get("edges", ())
    }
    primitives = []
    for edge in refinement.get("edges", ()):
        refined = edge.get("refined", {})
        start = np.asarray(refined.get("start_mm"), dtype=np.float64)
        end = np.asarray(refined.get("end_mm"), dtype=np.float64)
        if start.shape != (3,) or end.shape != (3,):
            continue
        if not np.isfinite(start).all() or not np.isfinite(end).all():
            continue
        source = source_by_id.get(int(edge.get("source_edge_id", -1)), edge)
        plane_count = len(set(int(value) for value in source.get("plane_ids", ())))
        category = min(3, max(1, plane_count))
        primitives.append({
            "refined_edge_id": int(edge.get("refined_edge_id", -1)),
            "source_edge_id": int(edge.get("source_edge_id", -1)),
            "plane_count": int(plane_count),
            "category": int(category),
            "start_mm": start.copy(),
            "end_mm": end.copy(),
            "color": _REFINER_EDGE_COLORS[category].copy(),
        })
    return primitives


def _segment_cylinder(start, end, radius, color):
    """Return a cylinder aligned to one finite 3-D segment."""
    start = np.asarray(start, dtype=np.float64)
    end = np.asarray(end, dtype=np.float64)
    delta = end - start
    length = float(np.linalg.norm(delta))
    if not np.isfinite(length) or length <= 1e-8:
        return None
    direction = delta / length
    z_axis = np.asarray([0.0, 0.0, 1.0])
    cosine = float(np.clip(z_axis @ direction, -1.0, 1.0))
    if cosine < -1.0 + 1e-10:
        rotation = np.diag([1.0, -1.0, -1.0])
    else:
        cross = np.cross(z_axis, direction)
        skew = np.asarray([
            [0.0, -cross[2], cross[1]],
            [cross[2], 0.0, -cross[0]],
            [-cross[1], cross[0], 0.0],
        ])
        rotation = np.eye(3) + skew + (skew @ skew) / max(1.0 + cosine, 1e-12)
    mesh = o3d.geometry.TriangleMesh.create_cylinder(
        radius=float(radius), height=length, resolution=12, split=1,
    )
    mesh.rotate(rotation, center=np.zeros(3))
    mesh.translate(0.5 * (start + end))
    mesh.paint_uniform_color(np.asarray(color, dtype=float))
    mesh.compute_vertex_normals()
    return mesh


def show_detector_validator_results(points_mm, validation, *, voxel_3d_mm):
    """Show only final validator edges and corners over neutral scene context."""
    points = np.asarray(points_mm, dtype=np.float64)
    edges = validation.get("final_edges", ())
    corners = validation.get("final_corners", ())
    diagnostics = validation.get("diagnostics", {})
    vis = o3d.visualization.Visualizer()
    title = (
        "Detector final | dense NMS -> shared validator -> refiner | "
        f"edges={len(edges)} corners={len(corners)} "
        f"queries={diagnostics.get('completed_count', 0)}/"
        f"{diagnostics.get('candidate_count', 0)} | "
        "orange=1-plane cyan=2-plane violet=3-plane red=corner"
    )
    if not vis.create_window(window_name=title, width=1100, height=820):
        print("[3D] Could not open detector final edge/corner view.")
        return
    cloud = o3d.geometry.PointCloud()
    cloud.points = o3d.utility.Vector3dVector(points)
    cloud.paint_uniform_color([0.16, 0.17, 0.20])
    vis.add_geometry(cloud)

    edge_radius = max(1.5, min(3.0, 0.18 * float(voxel_3d_mm)))
    for edge in edges:
        category = min(3, max(1, int(edge.get("plane_count", 1))))
        mesh = _segment_cylinder(
            edge["start_mm"], edge["end_mm"], edge_radius,
            _REFINER_EDGE_COLORS[category],
        )
        if mesh is not None:
            vis.add_geometry(mesh)
    corner_radius = max(4.0, 2.4 * edge_radius)
    for corner in corners:
        marker = o3d.geometry.TriangleMesh.create_sphere(
            radius=corner_radius, resolution=12,
        )
        marker.translate(np.asarray(corner["position_mm"], dtype=np.float64))
        marker.paint_uniform_color([1.0, 0.04, 0.04])
        marker.compute_vertex_normals()
        vis.add_geometry(marker)

    option = vis.get_render_option()
    option.background_color = np.asarray([0.018, 0.020, 0.027])
    option.point_size = 2.5
    if len(points):
        control = vis.get_view_control()
        control.set_lookat(np.mean(points, axis=0))
        control.set_front(normalize([0.75, 0.55, 0.65]))
        control.set_up(normalize([0.0, -1.0, 0.0]))
        control.set_zoom(0.72)
    vis.run()
    vis.destroy_window()


def open_plane_edge_graph_view(points_mm, analysis, previous=None):
    """Display only the immutable detector plane/edge graph."""
    if previous is not None:
        previous.destroy_window()
    points = np.asarray(points_mm, dtype=np.float64)
    vis = o3d.visualization.Visualizer()
    d = analysis['diagnostics']
    title = (f"Plane -> padded 2D boundary -> 3D Edge Graph | {analysis.get('search_scope', 'query')} "
             f"ROI={len(analysis['roi_point_indices'])} R={analysis.get('query_radius_mm') or 0:.1f}mm "
             f"planes={d['plane_count']} hough={d['hough_peaks']} "
             f"edges={d['merged_edge_count']} shared={d['shared_edge_count']} "
             f"corners={d.get('single_plane_corner_count',0)} "
             '| blue=Hough/PCA edge orange=detector corner')
    if not vis.create_window(window_name=title, width=1050, height=800):
        print('[3D] Could not open projected-Hough edge graph view.')
        return None
    base = o3d.geometry.PointCloud()
    local_ids = np.asarray(analysis["roi_point_indices"], dtype=np.int64)
    base.points = o3d.utility.Vector3dVector(points)
    base.paint_uniform_color([0.12, 0.13, 0.15])
    vis.add_geometry(base)
    core_cloud = o3d.geometry.PointCloud()
    core_cloud.points = o3d.utility.Vector3dVector(points[local_ids])
    core_cloud.paint_uniform_color([0.28, 0.30, 0.34])
    vis.add_geometry(core_cloud)
    # Explicitly show the spherical query neighborhood used by ALL stages.
    if analysis.get('query_position_mm') is not None and analysis.get('query_radius_mm'):
        q = np.asarray(analysis['query_position_mm'], dtype=float)
        r = float(analysis['query_radius_mm'])
        angles = np.linspace(0, 2*np.pi, 73)
        ring_points, ring_lines = [], []
        for a, b in ((0,1), (0,2), (1,2)):
            ring = np.tile(q, (len(angles),1))
            ring[:,a] += r * np.cos(angles)
            ring[:,b] += r * np.sin(angles)
            offset = len(ring_points)
            ring_points.extend(ring)
            ring_lines.extend([(offset+i,offset+i+1) for i in range(len(angles)-1)])
        radius_lines = o3d.geometry.LineSet()
        radius_lines.points = o3d.utility.Vector3dVector(np.asarray(ring_points))
        radius_lines.lines = o3d.utility.Vector2iVector(np.asarray(ring_lines))
        radius_lines.paint_uniform_color([0.95,0.35,0.20])
        vis.add_geometry(radius_lines)
    for i, plane in enumerate(analysis['planes']):
        # Show full plane support, not just a small boundary stripe in a gray scene.
        support_ids = np.asarray(plane['support_indices'], dtype=np.int64)
        if len(support_ids):
            plane_cloud = o3d.geometry.PointCloud()
            plane_cloud.points = o3d.utility.Vector3dVector(points[support_ids])
            base_rgb = np.asarray(_PLANE_COLORS[i % len(_PLANE_COLORS)], dtype=float)
            plane_cloud.paint_uniform_color((0.46 * base_rgb + 0.16).tolist())
            vis.add_geometry(plane_cloud)
            # Fitted plane wireframe in the original 3-D coordinate system.
            # Reuse fitted-plane coordinate frame and its observed 2-D range.
            plane_points = points[support_ids]
            origin = np.asarray(plane['center_mm'], dtype=float)
            u, v = np.asarray(plane['u'], dtype=float), np.asarray(plane['v'], dtype=float)
            planar = np.column_stack(((plane_points-origin)@u, (plane_points-origin)@v))
            lo, hi = np.min(planar, axis=0), np.max(planar, axis=0)
            coords = np.array([[lo[0],lo[1]],[hi[0],lo[1]],[hi[0],hi[1]],
                               [lo[0],hi[1]]], dtype=float)
            if np.linalg.norm(hi-lo) > 1e-6:
                wire = o3d.geometry.LineSet()
                wire.points = o3d.utility.Vector3dVector(
                    origin + coords[:,0,None]*u + coords[:,1,None]*v)
                wire.lines = o3d.utility.Vector2iVector([[0,1],[1,2],[2,3],[3,0]])
                wire.colors = o3d.utility.Vector3dVector(np.tile(base_rgb, (4,1)))
                vis.add_geometry(wire)
        ids = np.asarray(plane['boundary_indices'], dtype=np.int64)
        if len(ids) == 0:
            continue
        cloud = o3d.geometry.PointCloud()
        cloud.points = o3d.utility.Vector3dVector(points[ids])
        cloud.paint_uniform_color(_PLANE_COLORS[i % len(_PLANE_COLORS)])
        vis.add_geometry(cloud)
    # Detector output is retained as the immutable Hough/PCA initialization.
    segments = analysis['edges']
    if segments:
        xyz = np.vstack([[e['start_mm'], e['end_mm']] for e in segments])
        line_ids = np.asarray([[2*i,2*i+1] for i in range(len(segments))], dtype=np.int32)
        colors = np.asarray([[0.12, 0.48, 1.00] for _edge in segments], dtype=np.float64)
        lines = o3d.geometry.LineSet()
        lines.points = o3d.utility.Vector3dVector(xyz)
        lines.lines = o3d.utility.Vector2iVector(line_ids)
        lines.colors = o3d.utility.Vector3dVector(colors)
        vis.add_geometry(lines)
    # Single-plane boundary junctions are valid corner candidates even when
    # no other plane or shared edge has been observed.
    for corner in analysis.get('corners', []):
        # Marker radius is visualization-only, and does not affect localization.
        sphere = o3d.geometry.TriangleMesh.create_sphere(radius=4.0)
        sphere.compute_vertex_normals()
        sphere.paint_uniform_color([1.0, 0.34, 0.08])
        sphere.translate(np.asarray(corner['position_mm'], dtype=float))
        vis.add_geometry(sphere)
    opt = vis.get_render_option()
    opt.background_color = np.asarray([0.025,0.028,0.035])
    opt.point_size = 3.0
    opt.line_width = 5.0
    if analysis.get('query_position_mm') is not None:
        control = vis.get_view_control()
        control.set_lookat(np.asarray(analysis['query_position_mm'], dtype=float))
        control.set_front(normalize([0.75, 0.55, 0.65]))
        control.set_up(normalize([0.0, -1.0, 0.0]))
        control.set_zoom(0.72)
    return vis


def open_plane_edge_refiner_view(points_mm, analysis, previous=None):
    """Display refined planes, thick categorized edges, and refined corners."""
    if previous is not None:
        previous.destroy_window()
    refinement = analysis.get("refinement")
    if not refinement:
        return None
    points = np.asarray(points_mm, dtype=np.float64)
    primitives = plane_edge_refiner_primitives(analysis)
    counts = {
        category: sum(item["category"] == category for item in primitives)
        for category in (1, 2, 3)
    }
    diagnostics = refinement.get("diagnostics", {})
    title = (
        "Hough Edge Refiner | "
        f"graphs={diagnostics.get('graph_count', 0)} "
        f"edges={len(primitives)} (1P={counts[1]} 2P={counts[2]} 3P={counts[3]}) "
        f"corners={diagnostics.get('corner_count', 0)} | "
        "orange=1-plane cyan=2-plane violet=3-plane "
        "magenta=plane intersection red=corner"
    )
    vis = o3d.visualization.Visualizer()
    if not vis.create_window(
        window_name=title, width=850, height=800, left=1060, top=45,
    ):
        print("[3D] Could not open Hough edge refiner view.")
        return None

    base = o3d.geometry.PointCloud()
    base.points = o3d.utility.Vector3dVector(points)
    base.paint_uniform_color([0.09, 0.10, 0.12])
    vis.add_geometry(base)
    local_ids = np.asarray(analysis.get("roi_point_indices", ()), dtype=np.int64)
    if len(local_ids):
        core = o3d.geometry.PointCloud()
        core.points = o3d.utility.Vector3dVector(points[local_ids])
        core.paint_uniform_color([0.24, 0.26, 0.30])
        vis.add_geometry(core)

    # The refined plane context is deliberately muted so the thick edge
    # cylinders remain legible even on dense point clouds.
    for index, plane in enumerate(refinement.get("planes", ())):
        support_ids = np.asarray(plane.get("support_indices", ()), dtype=np.int64)
        if not len(support_ids):
            continue
        base_color = np.asarray(_PLANE_COLORS[index % len(_PLANE_COLORS)])
        cloud = o3d.geometry.PointCloud()
        cloud.points = o3d.utility.Vector3dVector(points[support_ids])
        cloud.paint_uniform_color((0.32 * base_color + 0.12).tolist())
        vis.add_geometry(cloud)

        refined = plane["refined"]
        center = np.asarray(refined["center_mm"], dtype=np.float64)
        u = np.asarray(refined["u"], dtype=np.float64)
        v = np.asarray(refined["v"], dtype=np.float64)
        planar = np.column_stack(((points[support_ids] - center) @ u,
                                  (points[support_ids] - center) @ v))
        lo, hi = np.min(planar, axis=0), np.max(planar, axis=0)
        if np.linalg.norm(hi - lo) > 1e-6:
            uv = np.asarray([
                [lo[0], lo[1]], [hi[0], lo[1]],
                [hi[0], hi[1]], [lo[0], hi[1]],
            ])
            wire = o3d.geometry.LineSet()
            wire.points = o3d.utility.Vector3dVector(
                center + uv[:, :1] * u + uv[:, 1:] * v
            )
            wire.lines = o3d.utility.Vector2iVector(
                np.asarray([[0, 1], [1, 2], [2, 3], [3, 0]], dtype=np.int32)
            )
            wire.paint_uniform_color(base_color)
            vis.add_geometry(wire)

    query_radius = float(analysis.get("query_radius_mm") or 0.0)
    edge_radius = max(1.5, min(3.0, query_radius * 0.018))
    intersection_radius = max(0.65, edge_radius * 0.45)
    for item in refinement.get("plane_intersections", ()):
        mesh = _segment_cylinder(
            item["start_mm"], item["end_mm"], intersection_radius,
            [1.00, 0.12, 0.82],
        )
        if mesh is not None:
            vis.add_geometry(mesh)
    for item in primitives:
        mesh = _segment_cylinder(
            item["start_mm"], item["end_mm"], edge_radius, item["color"],
        )
        if mesh is not None:
            vis.add_geometry(mesh)
    for corner in refinement.get("corners", ()):
        sphere = o3d.geometry.TriangleMesh.create_sphere(
            radius=max(4.0, 2.4 * edge_radius), resolution=12,
        )
        sphere.compute_vertex_normals()
        sphere.paint_uniform_color([1.0, 0.04, 0.04])
        sphere.translate(np.asarray(corner["position_mm"], dtype=np.float64))
        vis.add_geometry(sphere)

    options = vis.get_render_option()
    options.background_color = np.asarray([0.018, 0.020, 0.027])
    options.point_size = 2.5
    options.line_width = 2.0
    if analysis.get("query_position_mm") is not None:
        control = vis.get_view_control()
        control.set_lookat(np.asarray(analysis["query_position_mm"], dtype=float))
        control.set_front(normalize([0.75, 0.55, 0.65]))
        control.set_up(normalize([0.0, -1.0, 0.0]))
        control.set_zoom(0.72)
    return vis


__all__ = [
    "centroid_saliency_colors",
    "dense_heatmap_colors",
    "pca_ratio_heatmap_colors",
    "dense_heatmap_vmax",
    "corner_candidate_primitives",
    "cornervins_ahc_primitives",
    "cornervins_scene_roi_primitives",
    "synchronize_dense_camera_views",
    "dense_heatmap_panels",
    "show_dense_score_heatmaps",
    "open_cornervins_plane_views",
    "plane_edge_refiner_primitives",
    "show_detector_validator_results",
    "open_plane_edge_graph_view",
    "open_plane_edge_refiner_view",
]
