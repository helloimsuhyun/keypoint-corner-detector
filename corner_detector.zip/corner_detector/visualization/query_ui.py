"""Frozen-frame Tk query GUI for plane/edge diagnostics."""

from __future__ import annotations

import time

import numpy as np
from PIL import Image, ImageDraw
from pointcloud_inputs import PointCloudFrame

from ..constants import BUILD, WINDOW_FROZEN
from ..query_debug import inspect_query
from .manager import (
    close_query_views,
    poll_view_events,
    show_plane_edge_graph_view,
)

try:
    import tkinter as tk
    from PIL import ImageTk
except ImportError:
    tk = None
    ImageTk = None


def run_frozen_click_stage(
    frozen,
    cfg,
    *,
    initial_pixel=None,
    allow_reselection=True,
):
    if tk is None:
        raise RuntimeError("Tk is unavailable. Install Tk and Pillow in the active environment.")
    try:
        root = tk.Tk()
    except tk.TclError as exc:
        raise RuntimeError("Cannot open the Tk display: " + str(exc)) from exc

    action = None
    edge_debug_window = None
    edge_debug_view = None
    edge_debug_plane_index = 0
    edge_debug_peak_index = 0
    root.title(f"{WINDOW_FROZEN} | {BUILD}")
    query_instruction = "Click: query | " if allow_reselection else ""
    workflow_keys = "P/N: plane | J/K: Hough peak | "
    instructions = query_instruction + workflow_keys + "R: recapture | Q/Esc: quit"
    status = tk.StringVar(master=root, value=instructions)
    tk.Label(root, textvariable=status, anchor="w").pack(fill="x")
    frame_view = TkImagePanel(root, draw_frozen(frozen))
    set_image_window_size(root, frozen["rgb"], extra_height=35)

    def request_action(value):
        nonlocal action
        action = value

    def step_edge_debug_plane(delta):
        nonlocal edge_debug_plane_index, edge_debug_peak_index
        data = frozen.get('plane_edge_debug_clustering')
        if not data or not data.get('global_planes'):
            return
        edge_debug_plane_index = (edge_debug_plane_index + delta) % len(data['global_planes'])
        edge_debug_peak_index = 0
        refresh_edge_debug_window()

    def step_edge_debug_peak(delta):
        nonlocal edge_debug_peak_index
        graph = frozen.get("plane_edge_graph_result")
        raw = frozen.get("plane_edge_debug_clustering")
        count = 0
        if graph and raw and raw.get("global_planes"):
            raw_index = int(np.clip(edge_debug_plane_index, 0, len(raw["global_planes"]) - 1))
            plane_id = int(raw["global_planes"][raw_index]["plane_id"])
            fitted = next((p for p in graph["planes"] if int(p["plane_id"]) == plane_id), None)
            if fitted is not None:
                count = len(fitted.get("line_vote", {}).get("hough_peaks_after_nms", ()))
        edge_debug_peak_index = int(np.clip(edge_debug_peak_index + delta, 0, max(0, count - 1)))
        refresh_edge_debug_window()

    def key_cb(event):
        key = event.keysym.lower()
        if key in ("q", "escape", "r"):
            request_action("recapture" if key == "r" else "quit")
        elif key == "p":
            step_edge_debug_plane(-1)
        elif key == "n":
            step_edge_debug_plane(1)
        elif key == "j":
            step_edge_debug_peak(-1)
        elif key == "k":
            step_edge_debug_peak(1)

    def mouse_cb(event):
        if not allow_reselection:
            return
        point = frame_view.image_pixel(event.x, event.y)
        if point is not None:
            frozen["pending_query"] = point

    def close_edge_debug_window():
        nonlocal edge_debug_window, edge_debug_view
        if edge_debug_window is not None:
            edge_debug_window.destroy()
        edge_debug_window = None
        edge_debug_view = None

    def refresh_edge_debug_window():
        nonlocal edge_debug_window, edge_debug_view
        graph=frozen.get('plane_edge_graph_result')
        clustering=frozen.get('plane_edge_debug_clustering')
        edge_config=frozen.get('plane_edge_debug_config')
        if graph is None or clustering is None or edge_config is None:
            return
        from .plots import make_plane_edge_debug_figure, figure_to_rgb
        fig=make_plane_edge_debug_figure(
            graph, clustering, frozen['points_voxel_mm'], edge_config,
            edge_debug_plane_index, edge_debug_peak_index)
        try:
            rgb=figure_to_rgb(fig)
        finally:
            fig.clear()
        if edge_debug_window is None:
            edge_debug_window=tk.Toplevel(root)
            edge_debug_window.title(
                '3. Per-plane 2D projection | weighted Hough NMS | '
                'continuous line refinement | final segment NMS'
            )
            edge_debug_window.protocol('WM_DELETE_WINDOW', close_edge_debug_window)
            bar=tk.Frame(edge_debug_window)
            bar.pack(side='top',fill='x',pady=2)
            for name,callback in [('◀ Plane',lambda:step_edge_debug_plane(-1)),
                                  ('Plane ▶',lambda:step_edge_debug_plane(1)),
                                  ('◀ Peak',lambda:step_edge_debug_peak(-1)),
                                  ('Peak ▶',lambda:step_edge_debug_peak(1))]:
                tk.Button(bar,text=name,command=callback).pack(side='left',padx=3)
            tk.Label(bar,text='P/N: plane, J/K: peak | gray halo supplies neighborhoods only').pack(side='left',padx=10)
            edge_debug_view=TkImagePanel(edge_debug_window,rgb)
            set_image_window_size(edge_debug_window,rgb,extra_height=45)
        else:
            edge_debug_view.set_rgb(rgb)
        edge_debug_window.deiconify()

    root.protocol("WM_DELETE_WINDOW", lambda: request_action("quit"))
    root.bind_all("<KeyPress>", key_cb)
    frame_view.canvas.bind("<Button-1>", mouse_cb)
    if initial_pixel is not None:
        frozen["pending_query"] = (int(initial_pixel[0]), int(initial_pixel[1]))
    print(f"Frozen frame ({BUILD}): {instructions}", flush=True)
    try:
        while action is None:
            root.update_idletasks()
            root.update()
            if action is not None:
                break
            pending = frozen.pop("pending_query", None)
            if pending is not None:
                status.set("Computing planes, padded 2-D boundaries and 3-D graph...")
                root.update_idletasks()
                close_edge_debug_window()
                close_query_views(frozen)
                edge_debug_plane_index = 0
                edge_debug_peak_index = 0
                inspect_query(pending[0], pending[1], frozen, cfg)
                frame_view.set_rgb(draw_frozen(frozen))
                if frozen.get("plane_edge_debug_config") is not None:
                    refresh_edge_debug_window()
                    root.update_idletasks()
                show_plane_edge_graph_view(frozen, show_3d=cfg.show_3d)
                status.set(instructions)
            poll_view_events(frozen)
            time.sleep(0.01)
    finally:
        close_edge_debug_window()
        close_query_views(frozen)
        root.destroy()
    return action or "quit"


class TkImagePanel:
    def __init__(self, parent, rgb):
        self.canvas = tk.Canvas(parent, highlightthickness=0, background="#20242a")
        self.canvas.pack(fill="both", expand=True)
        self.item = self.canvas.create_image(0, 0, anchor="nw")
        self.photo = None
        self.layout = None
        self.source = Image.fromarray(np.asarray(rgb, dtype=np.uint8))
        self.canvas.bind("<Configure>", self.redraw)

    def set_rgb(self, rgb):
        self.source = Image.fromarray(np.asarray(rgb, dtype=np.uint8))
        self.redraw()

    def redraw(self, event=None):
        cw, ch = self.canvas.winfo_width(), self.canvas.winfo_height()
        if min(cw, ch) <= 1:
            return
        iw, ih = self.source.size
        scale = min(cw / iw, ch / ih)
        dw, dh = max(1, round(iw * scale)), max(1, round(ih * scale))
        left, top = (cw - dw) // 2, (ch - dh) // 2
        resized = self.source.resize((dw, dh), Image.Resampling.BILINEAR)
        self.photo = ImageTk.PhotoImage(resized, master=self.canvas)
        self.canvas.coords(self.item, left, top)
        self.canvas.itemconfigure(self.item, image=self.photo)
        self.layout = (left, top, dw, dh)

    def image_pixel(self, x, y):
        if self.layout is None:
            return None
        left, top, dw, dh = self.layout
        if not (left <= x < left + dw and top <= y < top + dh):
            return None
        iw, ih = self.source.size
        return (
            min(iw - 1, int((x - left) * iw / dw)),
            min(ih - 1, int((y - top) * ih / dh)),
        )


def set_image_window_size(window, rgb, extra_height=0):
    height, width = rgb.shape[:2]
    scale = min(
        1.0,
        0.9 * window.winfo_screenwidth() / width,
        max(1, 0.8 * window.winfo_screenheight() - extra_height) / height,
    )
    window.geometry(
        f"{max(1, round(width * scale))}x{max(1, round(height * scale)) + extra_height}"
    )


def draw_frozen(frozen: dict) -> np.ndarray:
    image = Image.fromarray(frozen["rgb"])
    point = frozen.get("selected_pixel")
    if point is not None:
        x, y = point
        draw = ImageDraw.Draw(image)
        draw.line((x - 12, y, x + 12, y), fill=(255, 0, 0), width=3)
        draw.line((x, y - 12, x, y + 12), fill=(255, 0, 0), width=3)
    return np.asarray(image).copy()


def run_validator_mode(
    frame: PointCloudFrame,
    frozen: dict,
    cfg,
) -> str:
    # Keep ``frame`` in the public signature used by the runner. The frozen
    # mapping contains the aligned RGB/depth data consumed by the Tk stage.
    _ = frame
    frozen.pop("selected_pixel", None)
    frozen.pop("pending_query", None)
    print("[QUERY] click a valid RGB/depth pixel in the frozen-frame window", flush=True)
    return run_frozen_click_stage(
        frozen,
        cfg,
        allow_reselection=True,
    )


# Library compatibility only. The CLI mode itself is now named ``validator``.
run_query_mode = run_validator_mode
