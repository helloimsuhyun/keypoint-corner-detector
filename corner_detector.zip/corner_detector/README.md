# `corner_detector` package

활성 validator의 평면 추출 경로는 하나다.

```text
query-core organized AHC
  -> per-region RANSAC/full-resolution refit
  -> repeated compatible-plane merge
  -> final convex hull
  -> padded boundary/Hough/3-D finite-edge graph/refiner
```

`query_debug.inspect_query`와 detector NMS seed는 모두
`validator_pipeline.run_validator_pipeline`을 호출한다. 평면 추출 backend 선택이나
별도 plane-cluster 활성화 옵션은 없다.

`cornervins_plane_extraction.py`가 AHC, RANSAC/refit, 병합, hull을 소유하고,
`preprocessing.py`가 organized pixel을 voxel scene-index domain으로 연결한다.
평면 fitting은 exact query radius 안에서만 수행된다.

이전의 multiscale Harris, SAH affinity graph, 독립 Edge3D 진단 경로는 삭제되었다.
